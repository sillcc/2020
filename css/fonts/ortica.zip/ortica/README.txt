## License

This typeface is available under the SIL Open Font License v1.1
See [OFL.txt] for more details.

## About Author

Collletttivo is an Open Source type foundry designing and distributing digital typefaces. 

Submit your work using Collletttivo typefaces at collletttivo@gmail.com